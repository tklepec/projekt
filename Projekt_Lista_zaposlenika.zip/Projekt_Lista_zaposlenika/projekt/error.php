<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" type="text/css" href="style.css">
    <meta charset="UTF-8">
    <title>Error</title>
</head>
<body>
    <div>
        <h1>Neispravan zahtjev</h1>
    </div>
    <div>
        <p>Oprostite, ali napravile ste neispravan zahtjev. Molim <a href="index.php">go back</a> pokušajte ponovno.</p>
    </div>
</body>
</html>

